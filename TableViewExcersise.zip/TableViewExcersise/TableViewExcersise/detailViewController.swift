//
//  detailViewController.swift
//  TableViewExcersise
//
//  Created by Z Ali on 3/8/22.
//

import UIKit

//created a protocol to manage data between classes
protocol Edit {
    func editedCell(index: Int, edit: String)
}


class detailViewController: UIViewController {
    @IBOutlet weak var txtField: UITextField!
    var name: String = ""
    var ind: Int = 0
    var edit: Edit?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        txtField.text = name
    }
    
    //sends back to main page
    @IBAction func backButton(_ sender: UIButton) {
        name = txtField.text ?? ""

        edit?.editedCell(index: ind, edit: name)
        navigationController?.popViewController(animated: false)
    }
    
}
