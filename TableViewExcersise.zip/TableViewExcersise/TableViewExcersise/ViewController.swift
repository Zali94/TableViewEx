//
//  ViewController.swift
//  TableViewExcersise
//
//  Created by Z Ali on 3/8/22.
//

import UIKit

class ViewController: UIViewController, Edit {
    @IBOutlet weak var tblView: UITableView!
    
    var array = ["Soccer", "Football", "Hockey", "Bastketball"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    //letting protocol know which cell was selected
    func editedCell(index: Int, edit: String) {
        array[index] = edit
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tblView.reloadData()
    }
    
}

//use of extentions here
extension ViewController: UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblView.dequeueReusableCell(withIdentifier: "cell")
        let obj = array[indexPath.row]
        cell?.textLabel?.text = obj
        return cell!
    }
    
    //passing the indexed item from the cell to the next view
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let st = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(identifier: "detailViewController") as! detailViewController
        vc.edit = self
        vc.name = array[indexPath.row]
        vc.ind = indexPath.row
        print(vc.name)
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
}


